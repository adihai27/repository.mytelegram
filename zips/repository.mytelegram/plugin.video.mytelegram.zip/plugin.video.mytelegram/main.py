import sys
import xbmcgui
import xbmcplugin

# כאן יבואו בעתיד ה-API ID וה-API HASH שלך
def run_addon():
    # קבלת ה-Handle של התוסף (מזהה ייחודי שקודי נותן לנו)
    handle = int(sys.argv[1])
    
    # יצירת פריט לדוגמה ברשימה
    list_item = xbmcgui.ListItem(label='התחברות לטלגרם (בקרוב)')
    
    # הוספת הפריט לממשק של קודי
    xbmcplugin.addDirectoryItem(handle=handle, url='', listitem=list_item, isFolder=False)
    
    # סיום בניית התפריט
    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    run_addon()