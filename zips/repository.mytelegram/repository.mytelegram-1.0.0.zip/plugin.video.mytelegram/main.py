import sys
import xbmcgui
import xbmcplugin
from telethon import TelegramClient

# כאן אתה מכניס את הפרטים שקיבלת מ-my.telegram.org
API_ID = 38243293 # המספר שקיבלת
API_HASH = '656e0263279caf87ceaf2d7313e0b0d6' # המחרוזת שקיבלת

def run_addon():
    handle = int(sys.argv[1])
    
    # יצירת חיבור לטלגרם (בשלב זה הוא יחפש קובץ סשן)
    client = TelegramClient('kodi_session', API_ID, API_HASH)
    
    # יצירת פריט בדיקה כדי לראות שהתוסף עולה בקודי
    list_item = xbmcgui.ListItem(label='החיבור לטלגרם פעיל!')
    xbmcplugin.addDirectoryItem(handle=handle, url='', listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    run_addon()